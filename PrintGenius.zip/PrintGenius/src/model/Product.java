package model;

public class Product {
    private int id;
    private String name;
    private String stock;
    private String brand;
    private String model;
    private String connectivity; // New field
    private String price;
    private String image;

    public Product() {
    }

    public Product(int id, String name, String stock, String brand, String model, String connectivity, String price, String image) {
        super();
        this.id = id;
        this.name = name;
        this.stock = stock;
        this.brand = brand;
        this.model = model;
        this.connectivity = connectivity; // New field
        this.price = price;
        this.image = image;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    // Stock
    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    // Brand
    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    // Connectivity
    public String getConnectivity() {
        return connectivity;
    }

    public void setConnectivity(String connectivity) {
        this.connectivity = connectivity;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public String toString() {
        return "Product [id=" + id + ", name=" + name + ", stock=" + stock + ", brand=" + brand + ", model=" + model + ", connectivity=" + connectivity + ", price=" + price + ", image="
                + image + "]";
    }
}
