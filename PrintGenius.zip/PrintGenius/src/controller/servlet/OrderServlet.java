package Servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DatabaseController.DatabaseConnection;
import Model.Cart;
import Model.Order;
import Model.User;

/**
 * Servlet implementation class OrderNowServlet
 */
@WebServlet("/OrderNowServlet")
public class OrderNowServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try(PrintWriter out = response.getWriter()){

			SimpleDateFormat formatter = new SimpleDateFormat("yyyy-mm-dd");
			
			User user = (User) request.getSession().getAttribute("auth");
	
			Date date = new Date();
		
			if(user != null) {
				String productId = request.getParameter("id");
				int productQuantity = Integer.parseInt(request.getParameter("quantity"));
				
				if(productQuantity <= 0) {
					productQuantity = 1;
				}
				
				Order orderModel = new Order();
				orderModel.setId(Integer.parseInt(productId));
				orderModel.setUid(user.getId());
				orderModel.setUid(user.getId());
				orderModel.setDate(formatter.format(date));
				
				DatabaseConnection orderdao = new DatabaseConnection();
				boolean result = orderdao.insertOrder(orderModel);
				
				if(result) {ArrayList<Cart> cart_list =( ArrayList<Cart>) request.getSession().getAttribute("cart-list");
				if(cart_list != null) {
					for(Cart c:cart_list) {
						if(c.getId()==Integer.parseInt(productId)) {
							cart_list.remove(cart_list.indexOf(c));
							break;
						}
					}
				}
					response.sendRedirect("orders.jsp");
				}else {
				out.println("order failed");
				}
				
			}else {
				response.sendRedirect("login.jsp");
			}
		
			
			}catch(Exception e){
				e.printStackTrace();
			}
		
		
	}

}
