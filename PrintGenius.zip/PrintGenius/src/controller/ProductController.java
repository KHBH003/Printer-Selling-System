package controller;
import java.sql.*;
import java.util.*;

import model.Product;

public class ProductController {
	private Connection con;

	private String query;
    private PreparedStatement pst;
    private ResultSet rs;
    

	public ProductController(Connection con) {
		super();
		this.con = con;
	}
	
	
	public List<Product> getAllProducts() {
        List<Product> products = new ArrayList<>();
        try {

            query = "select * from product";
            pst = this.con.prepareStatement(query);
            rs = pst.executeQuery();

            while (rs.next()) {
            	Product row = new Product();
                row.setId(rs.getInt("id"));
                row.setName(rs.getString("name"));
                row.setStock(rs.getString("stock"));
                row.setBrand(rs.getString("brand"));
                row.setModel(rs.getString("model"));
                row.setConnectivity(rs.getString("connectivity"));
                row.setPrice(rs.getString("price"));
                row.setImage(rs.getString("image"));

                products.add(row);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
        return products;
    }
	
}